package com.corp.controllers;   
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;

import com.corp.beans.Corporate;
import com.corp.dao.CorporateDao;  
@Controller  
public class CorporateController {  
    @Autowired  
    CorporateDao dao;
    @RequestMapping("/corpform")  
    public String showform(Model m){  
    	m.addAttribute("corp", new Corporate());
    	return "corpform"; 
    }  
    
    @RequestMapping(value="/save",method = RequestMethod.POST)  
    public String save(@ModelAttribute("corp") Corporate corp){  
        dao.save(corp);  
        return "redirect:/viewcorp"; 
    }  
    @RequestMapping("/viewemp")  
    public String viewemp(Model m){  
        List<Corporate> list=dao.getEmployees();  
        m.addAttribute("list",list);
        return "viewcorp";  
    }  
   
    @RequestMapping(value="/editcorp/{accountNo}")  
    public String edit(@PathVariable int id, Model m){  
        Corporate corp=dao.getEmpById(id);  
        m.addAttribute("command",corp);
        return "corpeditform";  
    }  
    @RequestMapping(value="/editsave",method = RequestMethod.POST)  
    public String editsave(@ModelAttribute("corp") Corporate corp){  
        dao.update(corp);  
        return "redirect:/viewcorp";  
    }  
    @RequestMapping(value="/deletecorp/{accountNo}",method = RequestMethod.GET)  
    public String delete(@PathVariable int id){  
        dao.delete(id);  
        return "redirect:/viewcorp";  
    }   
}  