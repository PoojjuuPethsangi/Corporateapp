package com.corp.beans;  
  
public class Corporate {  

private String corporateName;  
private String corporateId;  
private String accountNo;
/**
 * @return the corporateName
 */
public String getCorporateName() {
	return corporateName;
}
/**
 * @param corporateName the corporateName to set
 */
public void setCorporateName(String corporateName) {
	this.corporateName = corporateName;
}
/**
 * @return the corporateId
 */
public String getCorporateId() {
	return corporateId;
}
/**
 * @param corporateId the corporateId to set
 */
public void setCorporateId(String corporateId) {
	this.corporateId = corporateId;
}
/**
 * @return the accountNo
 */
public String getAccountNo() {
	return accountNo;
}
/**
 * @param accountNo the accountNo to set
 */
public void setAccountNo(String accountNo) {
	this.accountNo = accountNo;
}  
  

  
}  