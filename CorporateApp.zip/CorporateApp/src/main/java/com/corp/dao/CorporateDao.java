package com.corp.dao;  
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.util.List;  
import org.springframework.jdbc.core.BeanPropertyRowMapper;  
import org.springframework.jdbc.core.JdbcTemplate;  
import org.springframework.jdbc.core.RowMapper;

import com.corp.beans.Corporate;  
  
public class CorporateDao {  
JdbcTemplate template;  
  
public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
}  
public int save(Corporate p){  
    String sql="insert into corporate(corporateName,corporateId,accountNo) values('"+p.getCorporateName()+"',"+p.getCorporateId()+",'"+p.getAccountNo()+"')";  
    return template.update(sql);  
}  
public int update(Corporate p){  
    String sql="update corporate set corporateName='"+p.getCorporateName()+"', corporateId="+p.getCorporateId()+"' where accountNo="+p.getAccountNo()+"";  
    return template.update(sql);  
}  
public int delete(int id){  
    String sql="delete from corporate where id="+id+"";  
    return template.update(sql);  
}  
public Corporate getEmpById(int id){  
    String sql="select * from corporate where id=?";  
    return template.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Corporate>(Corporate.class));  
}  
public List<Corporate> getEmployees(){  
    return template.query("select * from corporate",new RowMapper<Corporate>(){  
        public Corporate mapRow(ResultSet rs, int row) throws SQLException {  
            Corporate e=new Corporate();  
            e.setCorporateName(rs.getString(1));  
            e.setCorporateId(rs.getString(2));  
            e.setAccountNo(rs.getString(3));  
            return e;  
        }  
    });  
}  
}  